"use client"; // Add this directive at the top

import React from 'react';

const Logan = () => {
  return (
    <div>Logan</div>
  )
}

export default Logan